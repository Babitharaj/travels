
import { useEffect, useState } from "react";
import styles from "./modalStructure.module.scss"
import {CgClose} from  'react-icons/cg'

 function ModalStructure ({ isOpen, onClose }) {
    if (!isOpen) return null;

   return (
  <>
   
    <div className={styles.backdrop}>
    <div className={styles.modalBody} style={{width:"80%"}}>
      <button onClick={onClose}>&times;</button>
      <div className={styles.modalContent}>

       <SlickSlider/>
      </div>
    </div>
  </div>
  

</>
   );
}

export default ModalStructure;
